# Trans2Kegg
Annotation pipeline for assigning KEGG orthologs to transcriptome or predicted protein sequences.
